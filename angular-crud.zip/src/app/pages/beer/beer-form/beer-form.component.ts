import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-beer-form',
  templateUrl: './beer-form.component.html',
  styleUrls: ['./beer-form.component.scss']
})
export class BeerFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
