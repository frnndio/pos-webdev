import { Component, OnInit } from '@angular/core';
// import { ApiService } from 'src/app/core/services/api.service';
import { ApiService } from 'src/app/core/services/beer.service';
// import { BeerService } from 'src/app/core/services/beer.service';
import { Beer } from 'src/app/core/model/beer.model';

@Component({
  selector: 'app-beer',
  templateUrl: './beer.component.html',
  styleUrls: ['./beer.component.scss']
})
export class BeerComponent implements OnInit {

  public beers;
  public itensQueEstaoSelecionados: number[];

  constructor(    
    // private beerService: BeerService
    private _api: ApiService
  ) { 
    
  }

  ngOnInit() {
    this._api.getBeers().subscribe(res => { 
      this.beers = res; 
      console.log(this.beers); 
      // this.isLoadingResults = false; }, err => { console.log(err); 
      // this.isLoadingResults = false; 
    });
  }

  itemSelecionado(item: number) {
    var posicaoDoItem = this.itensQueEstaoSelecionados.findIndex(i => item == i);
    if(this.itensQueEstaoSelecionados[posicaoDoItem] == item) {
      this.itensQueEstaoSelecionados.splice(posicaoDoItem, 1);
    } else {
      this.itensQueEstaoSelecionados.push(item)
    }
  }

  deletarItensSelecionados() {
    for(var i = 0; i < this.itensQueEstaoSelecionados.length; i++) {
      this._api.deleteBeer(this.itensQueEstaoSelecionados[i]);
    }
  }

        
}
