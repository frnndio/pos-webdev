import { NgModule } from '@angular/core';

import { BeerModule } from './beer/beer.module';

@NgModule({
  declarations: [
  ],
  imports: [
    BeerModule
  ],
  providers: [],
  bootstrap: []
})
export class PagesModule { }