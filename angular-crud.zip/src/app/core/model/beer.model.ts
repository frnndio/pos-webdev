export class Beer {
    _id: string;
    name: string;
    description: string;
}